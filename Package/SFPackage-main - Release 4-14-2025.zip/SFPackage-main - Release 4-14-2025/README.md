# Communication Panel Salesforce Integration

## Development Setup

Install [Node.js](https://nodejs.org/dist/v14.15.0/) (version 14.15.0, recommended to use same as build server).

Make sure you have the latest version of the Salesforce DX CLI before proceeding. Update info [here](https://developer.salesforce.com/docs/atlas.en-us.sfdx_setup.meta/sfdx_setup/sfdx_setup_update_cli.htm).

Create a new [Developer account](https://developer.salesforce.com/) if you don't have one. If using Visual Studio Code, the following commands can be executed with "Salesforce CLI Integration plugin". Turn on the Push-or-deploy-on-save in extension settings.

- Authenticate with your hub org:
    ```
    sfdx force:auth:web:login -d
    ```
- Create a scratch org and provide it with an alias:
    ```
    sfdx force:org:create -s -f config/project-scratch-def.json -a dev --setdefaultusername
    ```
- A sandbox test-user was created during scratch org creation. To generate a password for it, for logging into sandbox at https://test.salesforce.com:
    ```
    sfdx force:user:password:generate --targetusername <username>
    ```
- Point application to include debug version of the script in CPAdapter.page:11. Remember later to change it back to .min version before committing code changes:
    ```
    <apex:includeScript loadOnReady="true" value="{!$Resource.cpAdapter +'/cpAdapter.js'}" />
    ```
- Push the app to your scratch org:
    ```
    sfdx force:source:push
    ```
- Open the scratch org:
    ```
    sfdx force:org:open
    ```
- Proceed to [Enable CommunicationPanel in Salesforce](#enable-communicationPanel-in-salesforce)

## Enable CommunicationPanel in Salesforce

- In Salesforce UI, go to Settings (press Gear on right and Setup). In left-hand side menu go to Feature Settings -> Service -> Call Center -> Call Centers.
  - Click 'Edit' the Contact Center CTI Adapter.
    - Set 'Communication Panel URL' to any CC server containing CP (full URL to CP) or localhost CP development server (`npm run dev` in this folder => https://localhost:8443).
    - ONLY WHEN developing with local scratch enviroment, in 'CTI Adapter' value remove the "sinch__" namespace. Leave just "/apex/CPAdapter".
  - Select Manage Call Center Users, Add More Users, Find, and add any users needed.
- Type 'App Manager' in Quick Find.
  - Edit any lightning type app from the arrow menu in the right side of screen. 
    - In Utility items, add Open CTI Softphone. Save and go back.
- Back in App Launcher (9 dot menu on left side) select the app you modified. CP should now load in utility bar.
  
## Publishing Package

- Install the app dependencies and build the prod version. Make sure you are in the application root folder and type the following command:
    ```
    npm install && npm run dist
    ```
- Remember to point application back to include minimized version of the script in CPAdapter.page:11
- Get login credentials from [AWS secrets manager](https://eu-west-1.console.aws.amazon.com/secretsmanager/home?region=eu-west-1#!/secret?name=SalesforceTestAccounts)
- Authenticate to shared Developer account (publisher@sinch.com)
    ```
    sfdx force:auth:web:login -d
    ```
- Deploy the new source to shared account
    ```
    sfdx force:source:deploy --sourcepath src
    ```
- In Salesforce settings, type 'Package Manager' in Quick Find and select CommunicationPanel.
- Press Upload, modify Version Name and set Managed - Beta. Now upload the new version. 
- Change the install link in this page in the below [Package Installation Testing](#package-installation-testing) chapter to the one visible in Package Manager.
- Run e2e testing and package install testing with QA.
- Now change Managed - Released and upload the final release version. Change customer documentation to reflect the new install link.

## End-to-end Testing

- Get login credentials from [AWS secrets manager](https://eu-west-1.console.aws.amazon.com/secretsmanager/home?region=eu-west-1#!/secret?name=SalesforceTestAccounts)
- [Login to Salesforce](https://login.salesforce.com/) to shared Developer account as test user (test@sinch.com).
- CommunicationPanel should be available in the Sales app.

## Package Installation Testing

- Create a new [Developer account](https://developer.salesforce.com/) if you don't have one.
- Install the [Communication Panel Package](https://login.salesforce.com/packaging/installPackage.apexp?p0=04t09000000ApMd) to your account to all users.
- (Uninstall exiting CommunicationPanel package in Apps>Packaging>Installed Packages and logout from salesforce if install fails)
- Follow [Enable CommunicationPanel in Salesforce](#enable-communicationPanel-in-salesforce) and do a sanity test.

## Access to Shared Account 
- By default SF requires two factor authentication from untrusted IPs.
- To add an trusted tange (that is the a range of IP's the ISP grants for users), open the Settings page:
  - Security > Network Access
  - Add the IP range, so user's IP 91.154.168.21 becomes 91.154.0.0 to 91.154.255.255 