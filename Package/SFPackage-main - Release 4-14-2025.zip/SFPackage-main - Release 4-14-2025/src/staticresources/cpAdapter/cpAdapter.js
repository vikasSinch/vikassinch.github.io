// eslint-disable-next-line no-shadow-restricted-names
(function (cpAdapter, undefined) {
	"use strict";

	/**
	 * Reference to CP Iframe.
	 * @type {HTMLIFrameElement}
	 */
	var _frame;

	/**
	 * Reference to notification banner.
	 * @type {HTMLElement}
	 */
	var _notif; 

	/**
	 * CallCenter settings.
	 * @type {Object}
	 */
	var _settings;

	/**
	 * Message counter
	 * @type {number}
	 */
	var _msgId = 0;

	/**
	 * Callback map
	 * @type {object}
	 */
	var _callbacks = {};

	/**
	 * Translations mapS
	 * @type {object}
	 */
	var _t = {};

	/**
	 * Current queued interaction
	 * @type {object}
	 */
	var _queued;

	/**
	 * Current active interactions
	 * @type {object}
	 */
	var _interactions = {};

	/**
	 * Last interaction searched
	 */
    var _lastSearchedId = null;

	/**
	 * The Salesforce object ID/type of the currently confirmed object
	 */
	var _confirmedId = null;
	var _confirmedType = null;

	/**
	 * Timer to detect if CP is loaded
	 * @type {number}
	 */
	var _loadTimeout;

	/**
	 * Timer to detect if CP is loaded
	 * @type {object}
	 */
	var _logLevel = 3;

	/**
	 * Location of CP
	 * @type {string}
	 */
	var _cpUrl;

	/**
	 * Event channel Subscription
	 * @type {object}
	 */
	var _evtSubscription = null;

	/**
	 * Is CP ready to accept messages
	 * @type {boolean}
	 */
	var _ready = false;

	/**
	 * Number of leading characters to remove from phone number prior to search
	 * @type {number}
	 */
	var _phSearchRemoveLeadingChars = 0;

	/***
	 * Semi-colon separated list of prefixes to remove from search string
	 */
	var _reqSearchRemovePrefixes = [];

	/**
	 * Automatically Create Task On Single Match Accept
	 */
	var _autoCreateTaskSingleMatchAccept = false;

	/**
	 * Softphone layout from SF configuration
	 */
	var _sfSoftphoneLayout = null;

	/**
	 * Options for height of popup window
	 */
    var _windowHeight = { baseHeight: 168, oneResult: 200, threeOrMoreResults: 350 };

	/**
 * Removes the first matching prefix from the start of a string.
 * @param {string} input - The input string.
 * @param {string[]} prefixes - An array of prefixes to remove.
 * @returns {string} - The string with the prefix removed, if matched.
 */
	function removeMatchingPrefix(input, prefixes) {
		for (const prefix of prefixes) {
			if (input.startsWith(prefix)) {
				return input.slice(prefix.length);
			}
		}
		return input; // Return the original string if no prefix matches or if empty.
	}

	function makeNewEntityDefaultFields(entityType, details) {
		var retVal = {};

        switch (entityType) {
            case "Contact":
                retVal = {
                    FirstName: details.name.split(" ")[0],
                    LastName: details.name.split(" ").slice(1).join(" "),
                    Phone: details.phoneNumber,
                    Email: details.email
                };
                break;
            case "Lead":
                retVal = {
                    Name: details.name,
					Status: "Open - Contacted",
					Phone: details.phoneNumber,
					Email: details.email
                   // could use channel type as LeadSource: "Phone"
                };
				break;
			case "Account":
				retVal = {
					Name: details.name,
                    Phone: details.phoneNumber,
				};
				break;
			case "Case":
				retVal = {
					ContactEmail: details.email,
					ContactPhone: details.phoneNumber,
				};
				break;
            default:
                break;
        }

		return retVal;
	}

	/**
	 * Initialize controller
	 */
	function init() {
		try {
			_logLevel = window.sessionStorage.getItem("cp-debug") || 3;
		} catch (e) {
			//ignore
		}
		log("inf", "CPAdapter init v3", location.href);

		_frame = document.getElementById("cp-frame");
		_frame.style.width = "100%";
		_notif = document.getElementById("cp-incoming"); 
		// set default UI
		sforce.opencti.setSoftphonePanelLabel({ label: "Communication Panel" });
		sforce.opencti.setSoftphonePanelIcon({ key: "questions_and_answers" });
		sforce.opencti.setSoftphoneItemIcon({ key: "ban" });
		sforce.console.setCustomConsoleComponentPopoutable(false, function (result) {
			log("inf", "Pop-out feature " + result.success ? "successfully":"could not be" + " disabled");
		});

		// tell SF to not mess with our init
		sforce.opencti.notifyInitializationComplete();
		// load CC settings first
		sforce.opencti.getCallCenterSettings({
			callback: function (response) {
				if (response.success) {
					_settings = response.returnValue;
					var levels = ["DEBUG", "INFO", "WARNING", "ERROR", "NONE"];
					_logLevel = levels.indexOf(_settings["/reqGeneralInfo/reqLogLevel"]);
					_logLevel = _logLevel === -1 ? 3 : _logLevel;
					try {
						window.sessionStorage.setItem("cp-debug", _logLevel);
					} catch (e) {
						// ignore
					}
					log("inf", "Settings loaded", _settings);
					if (!_settings["/reqGeneralInfo/reqEndpoint"]) {
						fatalError();
						return;
					}

					if (_settings["/reqGeneralInfo/reqThirdParty"] === "true") {
						//  set up event channel TODO: This does not work in current SF
						log("dbg", "Enabling eventing", CHANNEL_IN, CHANNEL_OUT);
						sforce.opencti.subscribe({
							listener: onPublishMessage,
							channelName: CHANNEL_IN,
							callback: function (result) {
								if (!result.success) {
									log("wrn", "Failed to subscribe to event channel", CHANNEL_IN, result.errors);
								} else {
									_evtSubscription = result.subscription;
								}
							}
						});
					}

					_phSearchRemoveLeadingChars = _settings["/reqGeneralInfo/reqPhSearchRemoveLeadingChars"];
					if (_phSearchRemoveLeadingChars === NaN) {
                        _phSearchRemoveLeadingChars = 0;
					}
					log("dbg", "reqPhSearchRemoveLeadingChars", _phSearchRemoveLeadingChars);

					var tempSetting = _settings["/reqGeneralInfo/reqSearchRemovePrefixes"];
					try {
						if (tempSetting === "" || tempSetting === null || tempSetting === undefined) {
							_reqSearchRemovePrefixes = [];
						}
						else {
							_reqSearchRemovePrefixes = tempSetting.split(";");
						}
					} catch (e) {
                        _reqSearchRemovePrefixes = [];
					}
					
					log("dbg", "reqSearchRemovePrefixes", _reqSearchRemovePrefixes);
					
					tempSetting = _settings["/reqGeneralInfo/reqAutoCreateTaskSingleMatchAccept"];
					if (tempSetting === "true" || tempSetting === "True" || tempSetting === "TRUE") {						
                        _autoCreateTaskSingleMatchAccept = true;
					}
					log("dbg", "reqAutoCreateTaskSingleMatchAccept", _autoCreateTaskSingleMatchAccept);
					
					
	
					var sfUrl = new URL(_settings["/reqGeneralInfo/reqEndpoint"]);
					_cpUrl = sfUrl.origin +  sfUrl.pathname.replace(/\/[^\/]*$/, '');
					// replace index file to embedded
					sfUrl.pathname = sfUrl.pathname.replace(/index/, "embedded");

					// if no embedded.html found still then apend it to path.
					if (sfUrl.pathname.indexOf("embedded") === -1) {
						sfUrl.pathname = sfUrl.pathname + "/embedded.html";
					}
					
					var params = new URLSearchParams(sfUrl.search);
					// add salesforce = debug to query param
					if (!params.has('salesforce') && params.get('salesforce') !== 'true') {
						params.append('salesforce', 'true');
						sfUrl.search = params.toString();
					}

					_frame.src = sfUrl;

					//_cpUrl = _settings["/reqGeneralInfo/reqEndpoint"].replace("index.html", "").replace(/\/$/, "");
					//_frame.src = _cpUrl + "/embedded.html?salesforce=true";
					
					sforce.opencti.setSoftphoneItemLabel({ label: (_settings["/reqGeneralInfo/reqToolbarLabel"] || "CP") });
					_frame.onerror = fatalError;
					_loadTimeout = setTimeout(fatalError, 15000);
					window.addEventListener("message", onMessage, false);
					resize((response.returnValue["/reqGeneralInfo/reqSoftphoneHeight"] || 800), response.returnValue["/reqGeneralInfo/reqSoftphoneWidth"] || 600);
				} else {
					fatalError(response.errors);
				}
			}
		});

		// obtain the softphone layout details
		sforce.opencti.getSoftphoneLayout({
			callback: function (response) {
				if (response.success) {
					log("inf", "Softphone layout", response.returnValue);
					_sfSoftphoneLayout = response.returnValue;
				} else {
					log("wrn", "Failed to get softphone layout", response.errors);
				}
			}
		});
		sforce.opencti.onClickToDial({ listener: onCallOut });
	}

	/**
	 * Window message handler
	 * @param {Event} event Window event
	 */
	function onMessage(event) {
		if (event.source !== _frame.contentWindow) {
			return;
		}

		var message = event.data || {};
		var payload = message.payload || {};
		log("dbg", "onMessage", message);
		switch (message.type) {
			case "load":
				log("inf", "CP loaded");
				clearTimeout(_loadTimeout);
				break;
			case "init":
				// load up, let's check our work state on load
				setAppState();
				loadTranslations();
				(Array.isArray(payload.value) ? payload.value : []).some(function (interaction) {
					// check for active interactions
					if (interaction.status === "accepted" || interaction.status === "incoming" || interaction.status === "outbound") {
						sforce.opencti.setSoftphonePanelVisibility({ visible: true });
						return true;
					}
					return false;
				});
				_ready = true;
				log("dbg", "CP init complete");
				break;
			case "response":
				if (Object.prototype.hasOwnProperty.call(_callbacks, message.id)) {
					log("dbg", "Resolve request", message.id);
					_callbacks[message.id](message);
					delete _callbacks[message.id];
				}
				break;
			case "status":
				if (payload.attribute === "phone_status") {
					log("dbg", "Phone status", payload.value);
					if (payload.value === true) {
						sforce.opencti.enableClickToDial();
					} else {
						sforce.opencti.disableClickToDial();
					}
				} else if (payload.attribute === "login_status" || payload.attribute === "work_status") {
					setAppState();
				}
				break;
			case "state":
				if (payload.attribute === "status") {
					var int = payload.interaction;
					if (!int) {
						break;
					}
					log("dbg", "Interaction status", int.id, payload.value);
					if (int.id in _interactions) {
						_interactions[int.id].interaction = int;
					} else {
                        _interactions[int.id] = { interaction: int };
					}

                    log("dbg", "Interaction Value STATE", _interactions[int.id]);
					// toggle notification window 
					var elements = null;
					var dispArea = document.getElementById("cp-scroll");
					switch (payload.value) {
						case "incoming":
							_confirmedId = null;
							_confirmedType = null;
							sforce.opencti.setSoftphonePanelLabel({ label: getInteractionLabel(int) + "  |  From: " + int.originator + "  |  Queue: " + getQueueLabel(int) });
							sforce.opencti.setSoftphonePanelIcon({ key: getInteractionIcon(int) });
							
							// delete all previous search results
							elements = dispArea.querySelectorAll('.slds-docked-composer__lead');
							elements.forEach(element => {
								element.remove();
							});
							setAcceptRejectButtonStatus(true);
                            setNoMatchButtonStatus(false);
							
							toggleNotif(true, int);
							
							break;
						case "accepted":
							elements = dispArea.querySelectorAll('.slds-docked-composer__lead');
							if (_confirmedId == null && elements.length > 1) {
								log("dbg", "Call is Accepted with multiple search results. Awaiting confirmation of contact.");
								setAcceptRejectButtonStatus(false);
								setNoMatchButtonStatus(true);
							}
							else if (_confirmedId !== null) {
								toggleNotif(false, int);
							} else {
                                toggleNotif(true, int); // TODO in future avoid 2x search
							}
						case "outgoing":
							sforce.opencti.setSoftphonePanelLabel({ label: getInteractionLabel(int) + "  |  From: " + int.originator + "  |  Queue: " + getQueueLabel(int) });
							sforce.opencti.setSoftphonePanelIcon({ key: getInteractionIcon(int) });
							if (payload.value === "outgoing") {
								_interactions[int.id].isOutbound = true;
							} else if (_interactions[int.id].isOutbound === true) {
								_interactions[int.id].startTime = new Date();
								break;
							} else {
								_interactions[int.id].startTime = new Date();
							}
							// accepted new interaction => create SF task if it is detected
							/***
							lookupContact(int, function (contact) {
								if (!contact && _settings["/reqGeneralInfo/reqCreateContact"] === "true") {
									// create new contanct to db
									var details = getValuesFromInteraction(int);
									if ((!details.phoneNumber && !details.name && !details.email) || (int.from_queue.name === "OperDirect" && !int.orig_queue.id)) {
										// no identity => don't show the create popup
										return;
									}
									var name = details.name.split(" ");
									log("dbg", "Show contact create", details);
									sforce.opencti.screenPop({
										type: sforce.opencti.SCREENPOP_TYPE.NEW_RECORD_MODAL,
										params: {
											entityName: "Contact",
											defaultFieldValues: {
												FirstName: name.shift(),
												LastName: name.join(" "),
												Phone: details.phoneNumber,
												Email: details.email
											}
										}, callback: function (result) {
											if (!result.success) {
												log("wrn", "Show popup now", result.errors);
											}
										}
									});

								} else if (contact) {
									// Create an task under contact and navigates to that
									log("dbg", "Create interaction task", int.id);
									callApex("TaskController", "createTask", {
										"creatorId": contact,
										"subject": getInteractionLabel(int),
										"channel": int.channel_type,
										"status": "In Progress",
										"description": "",
										"duration": "",
										"result": int.channel_type === "phone" ? int.channel_status : "connected",
										"direction": (int.direction === "outbound" ? "Outbound" : "Inbound")
									}, function (result) {
										if (result) {
											_interactions[int.id].task = result;
										}
										cpAdapter.openDetails(contact);
									});
								}
							});
							**/
							break;
						case "ended":
							// ended call => complete the task
							sforce.opencti.setSoftphonePanelLabel({ label: "Communication Panel" });
							sforce.opencti.setSoftphonePanelIcon({ key: "questions_and_answers" });
							setNoMatchButtonStatus(false);
							setAcceptRejectButtonStatus(false);
							//contact = _interactions[int.id].contact;
							
							

								log("dbg", "Complete interaction task", int.id);
								var duration = "";
								if (_interactions[int.id].startTime) {
									duration = Math.round((new Date() - _interactions[int.id].startTime) / 1000);
								}
								if (_interactions[int.id].task) {
									callApex("TaskController", "completeTask", {
										"taskId": _interactions[int.id].task.Id,
										"duration": duration,
										"result": int.channel_type === "phone" ? int.channel_status : "disconnected"
									}, function (result) {
									//	cpAdapter.openDetails(contact.Id);
									});
								} else {
								//	var functionName = "createTask";
								//	if (_confirmedType === 'Account' || _confirmedType === 'Case') {
                                //        functionName = "createTaskWhat";
								//	}
								//	callApex("TaskController", functionName, {
								//		"creatorId": contact,
								//		"subject": getInteractionLabel(int),
								//		"channel": int.channel_type,
								//		"status": "Completed",
								//		"description": "",
								//		"duration": duration,
								//		"result": int.channel_type === "phone" ? int.channel_status : "disconnected",
								//		"direction": (int.direction === "outbound" ? "Outbound" : "Inbound")
								//	}, function (result) {
								//		if (result) {
								//			_interactions[int.id].task = result;
								//			cpAdapter.openDetails(contact);
								//		}
								//	});
								}
							toggleNotif(false, null, true);
							clearSearchResults();
							break;
						case "handled":
							setNoMatchButtonStatus(false);
							setAcceptRejectButtonStatus(false);
							toggleNotif(false, null, true);
							clearSearchResults();
							if (_interactions[int.id].task) {
								// check if there is new description to be added
								getTaskDescription(int, function (desc) {
									if (desc) {
										callApex("TaskController", "updateDescription", {
											"taskId": _interactions[int.id].task.Id,
											"description": desc,
										}, function (result) {
											refreshView();
										});
									}
									if (Object.prototype.hasOwnProperty.call(_interactions, int.id)) {
										delete _interactions[int.id];
									}
								});
							} else if (Object.prototype.hasOwnProperty.call(_interactions, int.id)) {
								delete _interactions[int.id];
							}
							break;
						default:
							break;
					}
				}
				break;
			default:
				break;
		}

		if (_evtSubscription && _ready) {
			sforce.opencti.publish({
				channelName: CHANNEL_OUT,
				message: event.data,
				callback: function (result) {
					if (!result.success) {
						log("wrn", "Failed to publish to event channel", CHANNEL_OUT, result.errors);
					}
				}
			});
		}

	}

	/**
	 * Listen to SF events from 3rd. party SF applications and forward them to CP
	 * @param {object} message Extension message
	 */
	function onPublishMessage(message) {
		if (_ready) {
			_frame.contentWindow.postMessage(message, _cpUrl);
		} else if (_evtSubscription && message.id) {
			sforce.opencti.publish({
				channelName: CHANNEL_OUT,
				message: { id: message.id, type: "response", payload: { value: "error", reason: "extension not initialized yet" } }
			});
		}
	}

	/**
	 * Set application icon based on the current user work state
	 */
	function setAppState() {
		// delay a bit the let model catch up
		setTimeout(function () {
			sendMessage("action", { command: "detail", value: "user" }, function (message) {
				var ready = message.payload.value.work_status === "ready" && message.payload.value.login_status === "logged_in";
				log("dbg", "Ready state", ready);
				sforce.opencti.setSoftphoneItemIcon({ key: (ready ? "questions_and_answers" : "ban") });
			});
		}, 3000);
	}

	/**
	 * Sends a XDM message to the visitor host application iframe.
	 * @param {string} type CP extension message type
	 * @param {object} data CP extension message payload
	 * @param {function} fnCallback Callback on completed message
	 * @param {string} id Message id
	 */
	function sendMessage(type, data, fnCallback, id) {
		var msgId = id || "cpc-" + _msgId++;
		var msg = { type: type, payload: data, id: msgId };
		log("dbg", "sendMessage", msg);
		if (fnCallback) {
			_callbacks[msgId] = fnCallback;
		}
		_frame.contentWindow.postMessage(msg, _cpUrl);
	}

	/**
	 * Clear the search results area
	 */
	function clearSearchResults() {
		var dispArea = document.getElementById("cp-scroll");
		// delete all previous search results
		const elements = dispArea.querySelectorAll('.slds-docked-composer__lead');
		elements.forEach(element => {
			element.remove();
		});
		_confirmedId = null;
		_confirmedType = null;
	}

	/***
	 * Based on the softphone layout settings, process the no search results scenario
	 */
	function processNoSearchResultsScenario() {
		var openRule = "existingWindow";
		var openInfo = null;
		if (_interactions[_lastSearchedId].isOutbound === true) {
			try {
				openRule = _sfSoftphoneLayout.Outbound.screenPopSettings.screenPopsOpenWithin;
				log("dbg", "Outbound screen pop settings. screenPopsOpenWithin: ", openRule);
			} catch (e) {
				log("err", "Failed to get outbound screen pop settings from softphone layout", e);
			}
		}
		else {
			try {
				openRule = _sfSoftphoneLayout.Inbound.screenPopSettings.screenPopsOpenWithin;
				log("dbg", "Inbound screen pop settings. screenPopsOpenWithin: ", openRule);

				openInfo = _sfSoftphoneLayout.Inbound.screenPopSettings.NoMatch;
				log("dbg", "Inbound screen pop settings. NoMatch: ", openInfo);
			} catch (e) {
				log("err", "Failed to get inbound screen pop settings from softphone layout", e);
			}
		}

		if (openInfo !== null && _interactions[_lastSearchedId].interaction.channel_status !== 'ringing') {
			if (openInfo.screenPopType === "PopToEntity") {
				// open the entity					
				//log("dbg", "Current id: ", _lastSearchedId);	
				log("dbg", "Current interaction: ", _interactions[_lastSearchedId].interaction);
				var details = getValuesFromInteraction(_interactions[_lastSearchedId].interaction);
				//log("dbg", "Current details: ", details);
				var fields = makeNewEntityDefaultFields(openInfo.screenPopData, details);
				//log("dbg", "Show object create", fields);
				sforce.opencti.screenPop({
					type: sforce.opencti.SCREENPOP_TYPE.NEW_RECORD_MODAL,
					params: {
						entityName: openInfo.screenPopData,
						defaultFieldValues: fields
					}, callback: function (result) {
						if (!result.success) {
							log("wrn", "Show popup", result.errors);
						}
					}
				});
			} else if (openInfo.screenPopType === "PopToURL") {
				// open the URL

				//window.open(openInfo.screenPopData, "_blank");
			} else if (openInfo.screenPopType === "DoNotPop") {
				// make task
			}
			// close the window
			toggleNotif(false, null, true);
		}
	}

	function processSingleMatchScenario( objectId, int) {
		var openRule = "existingWindow";
		var openInfo = null;
		if (_interactions[_lastSearchedId].isOutbound === true) {
			try {
				openRule = _sfSoftphoneLayout.Outbound.screenPopSettings.screenPopsOpenWithin;
				log("dbg", "Outbound screen pop settings. screenPopsOpenWithin: ", openRule);
			} catch (e) {
				log("err", "Failed to get outbound screen pop settings from softphone layout", e);
			}
		}
		else {
			try {
				openRule = _sfSoftphoneLayout.Inbound.screenPopSettings.screenPopsOpenWithin;
				log("dbg", "Inbound screen pop settings. screenPopsOpenWithin: ", openRule);

				openInfo = _sfSoftphoneLayout.Inbound.screenPopSettings.SingleMatch;
				log("dbg", "Inbound screen pop settings. SingleMatch: ", openInfo);
			} catch (e) {
				log("err", "Failed to get inbound screen pop settings from softphone layout", e);
			}
		}

		if (openInfo !== null && _interactions[_lastSearchedId].interaction.channel_status !== 'ringing') {
			// Always create task
			var functionName = "createTask";
			if (_confirmedType === 'Account' || _confirmedType === 'Case') {
				functionName = "createTaskWhat";
			}
			callApex("TaskController", functionName, {
				"creatorId": objectId,
				"subject": getInteractionLabel(int),
				"channel": int.channel_type,
				"status": "Completed",
				"description": "",
				"duration": "",
				"result": int.channel_type === "phone" ? int.channel_status : "disconnected",
				"direction": (int.direction === "outbound" ? "Outbound" : "Inbound")
			}, function (result) {
				if (result) {
					log("dbg", "createTask: Task created", result);
					_interactions[int.id].task = result;
				} else {
					log("err", "createTask: Failed to create task", result);
				}
			});

			if (openInfo.screenPopType === "DoNotPop") {
				//just make task
			} else if (openInfo.screenPopType === "PopToEntity") {
				// make task then open the entity					
				cpAdapter.openDetails(objectId);
				
			} else if (openInfo.screenPopType === "PopToURL") {
				// open the URL

				//window.open(openInfo.screenPopData, "_blank");
			}
			// close the window
			toggleNotif(false, null, true);
		}
		
	}

	function createTaskAndAssociate( objectId, int, pop) {
		var functionName = "createTask";
		if (_confirmedType === 'Account' || _confirmedType === 'Case') {
			functionName = "createTaskWhat";
		}
		callApex("TaskController", functionName, {
			"creatorId": objectId,
			"subject": getInteractionLabel(int),
			"channel": int.channel_type,
			"status": "Completed",
			"description": "",
			"duration": duration,
			"result": int.channel_type === "phone" ? int.channel_status : "disconnected",
			"direction": (int.direction === "outbound" ? "Outbound" : "Inbound")
		}, function (result) {
			if (result) {
				log("dbg", "createTask: Task created", result);
				_interactions[int.id].task = result;
				if (pop === true) {
					//TODO RULES
					cpAdapter.openDetails(contact);
				}
            } else {
				log("err", "createTask: Failed to create task", result);
			}
		});
	}

	/**
	 * Show/hide notification bubble if the system is in state where it is possible
	 * @param {boolean} maximized The state to go to
	 * @param {*} interaction ECF interaction reference
	 * @param {boolean} [toggle=true] Toggle the utility popover visibility too
	 */
	function toggleNotif(maximized, interaction, toggle) {
		if (maximized) {
			sforce.opencti.isSoftphonePanelVisible({
				callback: function (response) {
					//if (!response.success) {
					//	return;
					//}
					// show notif only when we are not expanded
					log("dbg", "Showing notif - callback");
					_queued = interaction;
					_notif.style.display = "block"; 
					_frame.style.display = "none";
                    
					resize(_windowHeight.baseHeight);

					//sforce.opencti.setSoftphonePanelLabel({ label: getInteractionLabel(interaction) + " | From: " + interaction.originator + " | Queue: " + getQueueLabel(interaction) });
					//sforce.opencti.setSoftphonePanelIcon({ key: getInteractionIcon(interaction) });

					var details = getValuesFromInteraction(interaction);
/***
					var nameField = document.getElementById("cp-name");
					var avatarField = document.getElementById("cp-avatar");
					var queueField = document.getElementById("cp-queue");
					addDetailFields([details.phoneNumber, details.email]);
					queueField.innerText = getQueueLabel(interaction);
					nameField.innerText = details.name || _t["ECF_XTIT_CP_UNKNOWN_CONTACT"];
					avatarField.innerText = details.name ? details.name[0] : "U";
***/
					if (toggle !== false) {
						sforce.opencti.setSoftphonePanelVisibility({ visible: true });
					}

					lookupContact(interaction, function (searchResult) {
						clearSearchResults(); 
                        var dispArea = document.getElementById("cp-scroll");

						// no results found
						if (searchResult === null || searchResult.length === 0) {
							resize(_windowHeight.oneHeight);
							setNoMatchButtonStatus(false);
							var template = document.getElementById("searchResTemplateNoResult");
							var cloneTemplate = template.content.cloneNode(true);
							dispArea.appendChild(cloneTemplate);
							processNoSearchResultsScenario();									
						} else if (searchResult.length === 1) {
							setNoMatchButtonStatus(false);
							resize(_windowHeight.oneHeight);
							// open the details of the only result 
							_confirmedId = searchResult[0].Id;
							_confirmedType = searchResult[0].attributes.type;
							_interactions[_lastSearchedId].contact = _confirmedId;
							processSingleMatchScenario(resValue.Id, _interactions[_lastSearchedId].interaction);
							toggleNotif(false, undefined, true);
						} else {
							if (_interactions[_lastSearchedId].interaction.channel_status !== 'ringing') {
								setNoMatchButtonStatus(true);
							}

							resize(_windowHeight.threeOrMoreResults);
							// update the search results
							for (const resValue of searchResult) {
								if (resValue.attributes.type === "Account") {
									var template = document.getElementById("searchResTemplateAccount");
									var cloneTemplate = template.content.cloneNode(true);
									cloneTemplate.querySelector("a").textContent = resValue.Name;
									cloneTemplate.querySelector("a").onclick = function () {
										cpAdapter.openDetails(resValue.Id);
									}
									cloneTemplate.querySelector("button").textContent = "Confirm";
									cloneTemplate.querySelector("button").onclick = function () {
										_confirmedId = resValue.Id;
										_confirmedType = resValue.attributes.type;										
										_interactions[_lastSearchedId].contact = _confirmedId;
                                        processSingleMatchScenario(resValue.Id, _interactions[_lastSearchedId].interaction);
										if (isAlerting() === true) {
											//cloneTemplate.querySelector("button")
										}
										else {
											toggleNotif(false, undefined, true);
										}
									};
									var detailList = cloneTemplate.querySelector("ul");
									var detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Owner: " + resValue.Owner.Name;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Type: " + resValue.Type;
									detailList.appendChild(detailItem);
									dispArea.appendChild(cloneTemplate);
								} else if (resValue.attributes.type === "Lead") {
									var template = document.getElementById("searchResTemplateLead");
									var cloneTemplate = template.content.cloneNode(true);
									cloneTemplate.querySelector("a").textContent = resValue.Name;
									cloneTemplate.querySelector("a").onclick = function () {
										cpAdapter.openDetails(resValue.Id);
									}
									cloneTemplate.querySelector("button").textContent = "Confirm";
									cloneTemplate.querySelector("button").onclick = function () {
										_confirmedId = resValue.Id;
										_confirmedType = resValue.attributes.type;
										_interactions[_lastSearchedId].contact = _confirmedId;
										processSingleMatchScenario(resValue.Id, _interactions[_lastSearchedId].interaction);
										if (isAlerting() === true) {
											//cloneTemplate.querySelector("button")
										}
										else {
											toggleNotif(false, undefined, true);
										}
									};
									var detailList = cloneTemplate.querySelector("ul");
									var detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Company: " + resValue.Company;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Status: " + resValue.Status;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Source: " + resValue.LeadSource;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Converted: " + resValue.IsConverted;
									detailList.appendChild(detailItem);
									dispArea.appendChild(cloneTemplate);
								} else if (resValue.attributes.type === "Contact") {
									var template = document.getElementById("searchResTemplateContact");
									var cloneTemplate = template.content.cloneNode(true);
									cloneTemplate.querySelector("a").textContent = resValue.Name;
									cloneTemplate.querySelector("a").onclick = function () {
										cpAdapter.openDetails(resValue.Id);
									}
									cloneTemplate.querySelector("button").textContent = "Confirm";
									cloneTemplate.querySelector("button").onclick = function () {
										_confirmedId = resValue.Id;
										_confirmedType = resValue.attributes.type;
										_interactions[_lastSearchedId].contact = _confirmedId;
										processSingleMatchScenario(resValue.Id, _interactions[_lastSearchedId].interaction);
										if (isAlerting() === true) {
											//cloneTemplate.querySelector("button")
										}
										else {
											toggleNotif(false, undefined, true);
										}
									};
									var detailList = cloneTemplate.querySelector("ul");
									var detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Company: " + resValue.Company;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Email: " + resValue.Email;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Phone: " + resValue.Phone;
									detailList.appendChild(detailItem);
									dispArea.appendChild(cloneTemplate);
								} else if (resValue.attributes.type === "Case") {
									var template = document.getElementById("searchResTemplateCase");
									var cloneTemplate = template.content.cloneNode(true);
									cloneTemplate.querySelector("a").textContent = resValue.Subject;
									cloneTemplate.querySelector("a").onclick = function () {
										cpAdapter.openDetails(resValue.Id);
									}
									cloneTemplate.querySelector("button").textContent = "Confirm";
									cloneTemplate.querySelector("button").onclick = function () {
										_confirmedId = resValue.Id;
										_confirmedType = resValue.attributes.type;
										_interactions[_lastSearchedId].contact = _confirmedId;
										processSingleMatchScenario(resValue.Id, _interactions[_lastSearchedId].interaction);
										if (isAlerting() === true) {
											//cloneTemplate.querySelector("button")
										}
										else {
											toggleNotif(false, undefined, true);
										}
									};
									var detailList = cloneTemplate.querySelector("ul");
									var detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Number: " + resValue.CaseNumber;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Priority: " + resValue.Priority;
									detailList.appendChild(detailItem);
									detailItem = document.createElement("li");
									detailItem.setAttribute("class", "slds-item");
									detailItem.textContent = "Status: " + resValue.Status;
									detailList.appendChild(detailItem);
									dispArea.appendChild(cloneTemplate);
								} else {
									log("err", "Unknown search result type", resValue.attributes.type);
								}
							};

						}
						//if (searchResult.Name) {
						//	nameField.innerHTML = "<a href='#' onclick='cpAdapter.openDetails(\"" + searchResult.Id + "\")'>" + searchResult.Name + "</a>";
						//	avatarField.innerText = (searchResult.FirstName[0] || "") + (searchResult.LastName[0] || "");
						//}
						//addDetailFields([searchResult.Title, searchResult.Department, (details.phoneNumber || searchResult.Phone), (details.email || searchResult.Email)]);
					});
					
				}
			});
		} else if (_notif.style.display === "block") {
			// notif visible => hide the cti panel
			log("dbg", "Hiding notif");
			_queued = null;
			_notif.style.display = "none"; 
			_frame.style.display = "block";
			sforce.opencti.setSoftphonePanelLabel({ label: "Communication Panel" });
			sforce.opencti.setSoftphonePanelIcon({ key: "questions_and_answers" });
			resize(_settings["/reqGeneralInfo/reqSoftphoneHeight"]);
			if (toggle !== false) {
				sforce.opencti.setSoftphonePanelVisibility({ visible: false });
			}
		}
	}

	/**
	 * Add contact's detail items to the notification banner
	 * @param {string[]} texts Strings to show below name
	 */
	function addDetailFields(texts) {
		var detailsField = document.getElementById("cp-details0");
		detailsField.innerHTML = "";
		texts.forEach(function (text) {
			if (!text) {
				return;
			}
			var elem = document.createElement("li");
			elem.setAttribute("class", "slds-item");
			elem.innerText = text;
			detailsField.appendChild(elem);
		});
	}

	/**
	 * Handle SF callout callback
	 * @param {object} event SF callout object
	 */
	function onCallOut(event) {
		sendMessage("action", { command: "outbound", value: { channel: "phone", to: event.number } });
		sforce.opencti.isSoftphonePanelVisible({
			callback: function (response) {
				if (!response.success) {
					return;
				}
				if (response.returnValue.visible === false) {
					sforce.opencti.setSoftphonePanelVisibility({ visible: true });
				}
			}
		});
	}

	/**
	 * Fatal error handler, cleanup and show error UI to user
	 * @param {object} reason Any reason string or error
	 */
	function fatalError(reason) {
		document.getElementById("cp-frame").style.display = "none";
		document.getElementById("cp-incoming").style.display = "none";
		document.getElementById("cp-error").style.display = "block";
		log.apply(this, ["err", "Failed to load CP. Verify Communication Panel URL in Call Centers", reason || ""]);
		_frame.src = "";
	}


	/**
	 * Detect contact information from SF based on ECF interaction
	 * @param {*} interaction ECF interaction reference
	 * @param {function} callback Result of the lookup
	 */
	function lookupContact(interaction, callback) {
		if (_interactions[interaction.id].contact) {
			callback(_interactions[interaction.id].contact);
		} else if (interaction.consult_for || (interaction.from_queue.name === "OperDirect" && !interaction.orig_queue.id)) {
			// consultation coming from other agent => do not try detect as a contact
            //TODO - read layout from SF
			callback(null);
		} else {
			var details = getValuesFromInteraction(interaction);
			var searchEmail = removeMatchingPrefix(details.email, _reqSearchRemovePrefixes);
			var searchPhone = details.phoneNumber.slice(_phSearchRemoveLeadingChars);
			searchPhone = removeMatchingPrefix(searchPhone, _reqSearchRemovePrefixes);
			var searchParams = { "name": details.name, "email": searchEmail, "phoneNumber": searchPhone, "direction": sforce.opencti.CALL_TYPE.INBOUND };
            _lastSearchedId = interaction.id;
			callSearch(searchParams, callback); 		

			
			//callApex("ContactController", "getContact", { "name": details.name, "email": searchEmail, "phoneNumber": details.phoneNumber.slice(_phSearchRemoveLeadingChars) }, function (result) {
			//	log("dbg", "Detected contact", result);
			//	_interactions[interaction.id].contact = result;
			//	callback(result);
			//});
		}
	}

	function callSearch(searchParams, callback ) {
		log("dbg", "callSearch", searchParams);
		// format params 
		sforce.opencti.searchAndScreenPop({
			searchParams: searchParams.phoneNumber,
			callType: searchParams.direction, 
			deferred: true,
			callback: function (response) {
				if (response.success) {
					// process the properties
					log("dbg", "searchAndScreenPop result", response);
					var searchEntities = [];
					for (const key in response.returnValue) {
						if (response.returnValue.hasOwnProperty(key)) {
							const value = response.returnValue[key];
							if (key != "SCREEN_POP_DATA") {
                                searchEntities.push({ "ResId": value.Id, "ResType": value.RecordType });
							}
							console.log(`Attribute: ${key}, Value: ${value}`);							 
						}
					}
					if (searchEntities.length > 0) {
						callApex("SearchResController", "GetSearchResFieldsStr", { "searchResultStr": JSON.stringify(searchEntities) }, function (result) {
							log("dbg", "APEX RESULTS", result);
							
							callback(result);
						});
					}
					else {
						log("dbg", "No search results to process");
						callback(null);
					}
					
                } else {
					log("wrn", "searchAndScreenPop failed", response.errors);
                    callback(null);
                }
			}
		});
	}

	/**
	 * Gets description for the SF task based on interaction. Returns empty string, when no description avaulable.
	 * @param {object} interaction ECF interaction
	 * @param {function} callback Result of the method
	 */
	function getTaskDescription(interaction, callback) {
		sendMessage("action", { command: "detail", value: "remarks", interactionId: interaction.id }, function (resp) {
			var remarks = (resp.payload.value || "").split("\n");
			remarks = remarks.filter(function (row) {
				return row !== "";
			});
			if (remarks.length > 0) {
				log("dbg", "Adding remarks", resp.payload.value);
				remarks.unshift(_t["ECF_XTIT_CP_INTERNAL_REMARKS"]);
			}
			remarks = remarks.map(function (row) {
				var stampEnd = row.indexOf("}");
				if (stampEnd > row.indexOf("{UTC_")) {
					var date = new Date(row.slice(5, stampEnd));
					row = pad0(date.getHours()) + ":" + pad0(date.getMinutes()) + ":" + pad0(date.getSeconds()) + row.slice(stampEnd + 1);
				}
				return row;
			});
			if (interaction.channel_type === "chat" && interaction.transcript.messages.length > 0) {
				// append transcript
				log("dbg", "Adding transcript", interaction.transcript.messages);
				remarks.push(_t["ECF_XTIT_CHATTRANSCRIPTTABLEHEADER"]);
				interaction.transcript.messages.forEach(function (msg) {
					if (msg.type === "state") {
						// ignore state messages
						return;
					}
					var origin = interaction.participants.find(function (part) {
						return part.uniquekey === msg.originator;
					});
					// UTC comes in Europe date format?
					var date = new Date(msg.timestamp.slice(3, 6) + msg.timestamp.slice(0, 3) + msg.timestamp.slice(6));
					remarks.push(pad0(date.getHours()) + ":" + pad0(date.getMinutes()) + ":" + pad0(date.getSeconds()) + " - " + (origin ? origin.alias : _t["ECF_XTIT_CP_UNKNOWN_CONTACT"]));
					if (msg.type === "attachment") {
						remarks.push(_t["ECF_XTIT_CP_ATTACHMENTS"]);
					} else if (msg.type === "template") {
						remarks.push(_t["ECF_XTOL_REPLY_TEMPLATE"]);
					} else {
						remarks.push(msg.message);
					}
				});
			}
			// add link to CP
			if (remarks.length > 0) {
				remarks.push("");
			}
			remarks.push(_cpUrl + "/index.html#interactionid=" + interaction.id);
			// encode as some characters might get mangled
			callback(encodeURIComponent(remarks.join("\n")));
		});
	}

	/**
	 * Adds leading zero to time
	 * @param {number|string} input input time
	 * @param {number} [width] optionally define the width of the return
	 * @returns {string} padded time
	 */
	function pad0(input, width) {
		input = String(input || 0);
		width = width || 2;
		if (input === "NaN") {
			return "00";
		}
		if (input.length > width) {
			return input;
		}
		return ("000" + input).slice(-width);
	}

	/**
	 * Call Apex function in the backend. This does not throw, it will return null on error or when no result is found.
	 * @param {string} controller Name of the Apex controller
	 * @param {string} method Method inside the controller
	 * @param {{}} params Map of the parameters
	 * @param {function} callback Result of the call
	 */
	function callApex(controller, method, params, callback) {
		var methodParams = "";
		Object.keys(params).forEach(function (key) {
			methodParams += key + "=" + (params[key] || null) + "&";
		});
		log("dbg", "Call Apex", controller, method, methodParams);
		var args = {
			//apexClass: "sinch." + controller,
			apexClass: controller,
			methodName: method,
			methodParams: methodParams.slice(0, -1),
			callback: function (result) {
				if (result.success) {
					try {
						var parsed = JSON.parse(result.returnValue.runApex);
						log("dbg", "Apex result", parsed);
						callback(parsed);
					} catch (err) {
						log("wrn", "Apex result parse", err.message);
						callback(null);
					}
				} else {
					log("wrn", "Apex call", result.errors);
					callback(null);
				}
			}
		};
		sforce.opencti.runApex(args);
	}

	/**
	 * Detect user information from ECF interaction.
	 * @param {object} interaction ECF interaction reference
	 * @returns {object} Name, email and phone number
	 */
	function getValuesFromInteraction(interaction) {
		var result = {
			phoneNumber: "",
			name: "",
			email: "",
		};

		if (interaction.direction === "outbound") {
			switch (interaction.channel_type) {
				case "phone":
					result.phoneNumber = interaction.destination;
					break;
				case "email":
					result.email = ((interaction.draft.to_address && interaction.draft.to_address.length > 0) ? interaction.draft.to_address[0].address : undefined);
					break;
				case "chat":
					var subChannelsOut = ["instagram", "line", "mms", "nativechannel", "sms", "telegram", "viber", "wechat", "whatsapp", "xms"];
					if (subChannelsOut.indexOf(interaction.channel_sub_type) !== -1) {
						result.phoneNumber = interaction.destination;
						break;
					}
					if (interaction.channel_sub_type === "facebook") {
						result.email = interaction.destination + "@facebook.com";
						break;
					}
					break;
				default:
					break;
			}
		} else {
			switch (interaction.channel_type) {
				case "phone":
					result.phoneNumber = interaction.originator;
					break;
				case "email":
					result.email = interaction.originator;
					break;
				case "chat":
					var subChannels = ["instagram", "line", "mms", "nativechannel", "sms", "telegram", "viber", "wechat", "whatsapp", "xms"];
					if (subChannels.indexOf(interaction.channel_sub_type) !== -1) {
						var number = interaction.originator.split("_");
						result.phoneNumber = number[1];
						break;
					}
					var participant = interaction.participants.find(function (part) {
						return part.uniquekey === interaction.originator;
					});
					if (participant && participant.alias !== "visitor") {
						result.name = participant.alias;
					}
					if (interaction.channel_sub_type === "facebook") {
						var email = interaction.originator.split("_");
						result.email = email[1] + "@facebook.com";
						break;
					}
					if (participant && participant.uniquekey && !(participant.uniquekey[4] === "." && participant.uniquekey[9] === "@" && participant.uniquekey[14] === ".")) {
						result.email = participant.uniquekey;
					}
					break;
				default:
					break;
			}
		}
		return result;
	}

	/**
	 * Set desired size for the popover
	 * @param {number} height Height in pixels
	 * @param {number} width Width in pixels
	 */
	function resize(height, width) {
		if (height) {
			var nHeight = parseInt(height, 10);
			_frame.height = nHeight - 47;
			sforce.opencti.setSoftphonePanelHeight({ heightPX: nHeight });
		}
		if (width) {
			var nWidth = parseInt(width, 10);
			_frame.width = nWidth - 2;
			sforce.opencti.setSoftphonePanelWidth({ widthPX: nWidth });
		}
	}

	/**
	 * Get translation file from CP
	 */
	function loadTranslations() {
		sendMessage("action", { command: "detail", value: "user" }, function (message) {
			var language = "_" + (message.payload.value.language || "en");
			if (document.body.getElementsByTagName("script")[1].src.indexOf(".min.js") === -1) {
				language = "";
			}
			sendRequest(_cpUrl + "/../resources/sap/ecf/bundles/i18n" + language.toLowerCase() + ".properties", null, function (resp) {
				if (!resp) {
					fatalError("Failed to load translations");
					return;
				} else {
					var rows = resp.responseText.split(/\r?\n/);
					rows.forEach(function (row) {
						if (row[0] !== "#") {
							var word = row.split("=");
							if (word.length === 2) {
								try {
									_t[word[0]] = JSON.parse('"' + word[1].replace(/"/g, '\\"') + '"');
								} catch (e) {
									log("wrn", "Parse translation", word[0], word[1], e.message);
									_t[word[0]] = word[1];
								}
							}
						}
					});
				}
				// translate UI
				document.getElementById("cp-accept").innerText = _t["ECF_XBUT_ACCEPT"];
				document.getElementById("cp-decline").innerText = _t["ECF_XBUT_REJECT"];
				//document.getElementById("cp-name").innerText = _t["ECF_XTIT_CP_UNKNOWN_CONTACT"];
			 
				 
			}, "application/json");
		});
	}

	/**
	 * Send HTTP GET request. Returns null on failed request.
	 * @param {string} url Destination URL
	 * @param {object} headers HTTP headers
	 * @param {function} callback Response handler
	 * @param {string} [mimeType] Force mimetype of response
	 */
	function sendRequest(url, headers, callback, mimeType) {
		var request = new XMLHttpRequest();
		request.onreadystatechange = function () {
			if (request.readyState === 4) {
				if (request.status === 200) {
					callback(request);
				} else {
					callback(null);
				}
			}
		};
		request.timeout = 5000;
		request.ontimeout = function () {
			callback(null);
		};
		headers = headers || {};
		request.open("GET", url, 1);
		request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		Object.keys(headers).forEach(function (key) {
			request.setRequestHeader(key, headers[key]);
		});
		if (mimeType && request.overrideMimeType) {
			request.overrideMimeType(mimeType);
		}
		request.send();
	}

	/**
	 * Write to console log
	 * @param {string} level Severity
	 * @param {string} msg Log message
	 * @param {array} params Any extra parameters
	 */
	function log(level, msg, params) {
		var levels = ["dbg", "inf", "wrn", "err"];
		var index = levels.indexOf(level);
		if (index < _logLevel) {
			return;
		}
		var args = arguments;

		switch (index) {
			case 3:
				args[0] = "ERR>";
				console.error.apply(this, args);
				break;
			case 2:
				args[0] = "WRN>";
				console.warn.apply(this, args);
				break;
			case 1:
				args[0] = "INF>";
				console.info.apply(this, args);
				break;
			default:
				args[0] = "DBG>";
				console.log.apply(this, args);
				break;
		}
	}

	/**
	 * Resolve interaction label
	 * @param {object} int Interaction object
	 * @returns {string} Translated channel type text
	 */
	function getInteractionLabel(int) {
		var tag;
		if (int.from_queue.name === "OperDirect" && !int.orig_queue.id) {
			switch (int.channel_type) {
				case "chat":
					tag = (int.channel_sub_type === "video" ? "ECF_XMIT_CONSULTATION_VIDEO_CHAT" : "ECF_XMIT_CONSULTATION_TEXT_CHAT");
					break;
				case "phone":
					tag = "ECF_XMIT_CONSULTATION_CALL";
					break;
				default:
					break;
			}
		} else if (int.direction === "outbound") {
			switch (int.channel_type) {
				case "chat":
					tag = (int.channel_sub_type === "text" ? "ECF_XTIT_CP_OUTGOING_CHAT" : "ECF_XTIT_CP_OUTGOING_" + int.channel_sub_type.toUpperCase() + "_CHAT");
					break;
				case "phone":
					tag = "ECF_XTIT_CP_OUTGOING_CALL";
					break;
				case "email":
					return int.title || _t["ECF_XTIT_CP_OUTGOING_EMAIL"];
				default:
					break;
			}
		} else {
			switch (int.channel_type) {
				case "chat":
					tag = (int.channel_sub_type === "text" ? "ECF_XTIT_CP_INCOMING_CHAT" : "ECF_XTIT_CP_INCOMING_" + int.channel_sub_type.toUpperCase() + "_CHAT");
					break;
				case "phone":
					tag = "ECF_XTIT_CP_INCOMING_CALL";
					break;
				case "user_defined":
					tag = (int.channel_sub_type === "action_item" ? "ECF_XTIT_CP_INCOMING_ACTION_ITEM" : "ECF_XTIT_CP_INCOMING_TASK");
					break;
				case "email":
					return int.title || _t["ECF_XTIT_CP_INCOMING_EMAIL"];
				default:
					break;
			}
		}
		return (_t[tag] || (int.direction === "outbound" ? _t["ECF_XFLD_OUTGOING"] : _t["ECF_XFLD_CP_INCOMING"]));
	}

	/**
	 * Resolve interaction icon
	 * @param {object} int ECF interaction
	 * @returns {string} SF icon code
	 */
	function getInteractionIcon(int) {
		switch (int.channel_type) {
			case "chat":
				return (int.channel_sub_type === "sms" ? "sms" : "chat");
			case "phone":
				return (int.channel_sub_type === "inbound" ? "incoming_call" : "outbound_call");
			case "user_defined":
				return (int.channel_sub_type === "action_item" ? "alert" : "task");
			case "email":
				return "email";
			default:
				return "question";
		}
	}

	/**
	 * Resolve queue name
	 * @param {object} int ECF interaction
	 * @returns {string} Queue name
	 */
	function getQueueLabel(int) {
		var name = int.from_queue.name;
		if (name === "OperDirect") {
			name = !int.orig_queue.id ? _t["ECF_XBUT_CONSULT"] : _t["ECF_XBUT_TRANSFER"];
		}
		return name;
	}

  /**
  * SetAcceptRejectButtonStatus
  * @param {boolean} value Show or hide accept/reject buttons
  */
	function setAcceptRejectButtonStatus(value) {
		if (value) {
			document.getElementById("cp-accept").style.display = "block";
			document.getElementById("cp-decline").style.display = "block";
		} else {
			document.getElementById("cp-accept").style.display = "none";
			document.getElementById("cp-decline").style.display = "none";
		}
	}

	/**
	 * SetNoMatchButtonStatus
	 * @param {any} value Show or hide no match button
	 */
    function setNoMatchButtonStatus(value) {
        if (value) {
            document.getElementById("cp-nomatch").style.display = "block";
        } else {
            document.getElementById("cp-nomatch").style.display = "none";
        }
    }

	/**
	 * IsAlerting
	 */
	function isAlerting() {
		return document.getElementById("cp-accept").style.display === "block";
	}

	/**
	 * Notification callback - accept pending interaction
	 */
	cpAdapter.accept = function () { 
		if (_queued) {
			log("dbg", "Accept", _queued.id);
			sendMessage("action", { command: "interaction", value: "accept", interactionId: _queued.id });
		}
		//toggleNotif(false, undefined, false);
	};

	/**
	 * Notification callback - reject pending interaction
	 */
	cpAdapter.decline = function () {
		if (_queued) {
			log("dbg", "Decline", _queued.id);
			sendMessage("action", { command: "interaction", value: "reject", interactionId: _queued.id });
		}
		sforce.opencti.setSoftphonePanelVisibility({ visible: false });
	};

   /**
   * Notification callback - no match after answer
   */
	cpAdapter.nomatch = function () { 
		// this is executed when there are multiple search results, but none of the matches are correct
		try {
			processNoSearchResultsScenario();
		} catch (e) {
			//
		}
	};

	/**
	 * Notification callback - show details in SF
	 * @param {string} id Contact id in SF
	 */
	cpAdapter.openDetails = function (id) {
		log("dbg", "Show details", id);
		sforce.opencti.getAppViewInfo({
			callback: function (response) {
				if (response.success && response.returnValue.recordId === id) {
					sforce.opencti.refreshView();
				} else {
					sforce.opencti.screenPop({
						type: sforce.opencti.SCREENPOP_TYPE.SOBJECT, params: { recordId: id }, callback: function (result) {
							if (!result.success) {
								log("wrn", "Show popup", result.errors);
							}
						}
					});
				}
			}
		});

	};

	// init on script load
	init();

	}(window.cpAdapter = window.cpAdapter || {}));
